function bio() {
    /** variables **/
    var name = "Laura Uribe";
    var role = "Associate Consultant";
    var contacts = new Object(); /** JSON **/
    contacts.mobile = "571-314-1037";
    contacts.email = "ur.laura@outlook.com";
    contacts.github = "laura-uribe";
    contacts.location = "Washington, DC";
    var welcomeMessage = "Hello! Please take a look around :)";
    var biopic = new URL("http://vignette3.wikia.nocookie.net/southpark/images/c/c2/Butters_(Facebook).jpg/revision/latest?cb=20101010032409");


    /** changed for helper.js **/
    var formattedName = HTMLheaderName.replace("%data%", name);
    var formattedRole = HTMLheaderRole.replace("%data%", role);
    var formattedMobile = HTMLmobile.replace("%data%", contacts.mobile);
    var formattedEmail = HTMLemail.replace("%data%", contacts.email);
    var formattedGitHub = HTMLgithub.replace("%data%", contacts.github);
    var formattedLocation = HTMLlocation.replace("%data%", contacts.location);
    var formattedWelcome = HTMLwelcomeMsg.replace("%data%", welcomeMessage);
    var formattedBiopic = HTMLbioPic.replace("%data%", biopic);


    /** changed for index.html **/
    $("#header").prepend(formattedRole);
    $("#header").prepend(formattedName);
    $("#topContacts").prepend(formattedMobile);
    $("#topContacts").append(formattedEmail);
    $("#topContacts").append(formattedGitHub);
    $("#topContacts").append(formattedLocation);
    $("#header").append(formattedWelcome);
    $("#header").append(formattedBiopic);
}

bio();

/************************************************************************************************/

function education() {
    var schools_all = {
        "schools": [
            {
                "name": "American University",
                "location": "Washington, DC",
                "degree": "Bachelor of Science",
                "majors": ["Computer Science", "Business Administration"],
                "dates": "2012-2016",
                "url": "www.american.edu"
            },
            {
                "name": "FIDM",
                "location": "New York, NY",
                "degree": "Associates",
                "majors": "Fashion Merchandising",
                "dates": "2016",
                "url": "www.fidm.com"
            }
         ],
        "onlineCourses": [
            {
                "title": "Front-End Developer Nanodegree",
                "school": "Udacity",
                "dates": "2016",
                "url": "www.udacity.com"
            }
        ]
    };

    /** changed for helper.js **/
    var formattedSchoolName = HTMLschoolName.replace("%data%", schools_all.schools["name"]);
    var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", schools_all.schools["location"]);
    var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", schools_all.schools["degree"]);
    var formattedSchoolMajors = HTMLschoolMajor.replace("%data%", schools_all.schools["majors"]);
    var formattedSchoolDates = HTMLschoolDates.replace("%data%", schools_all.schools["dates"]);

    var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", schools_all.onlineCourses.title);
    var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", schools_all.onlineCourses.school);
    var formattedOnlineDates = HTMLonlineDates.replace("%data%", schools_all.onlineCourses.dates);
    var formattedOnlineURL = HTMLonlineURL.replace("%data%", schools_all.onlineCourses.url);

    /** changed for index.html **/
    $("#education").prepend(formattedSchoolName);
    $("#education").append(formattedSchoolLocation);
    $("#education").append(formattedSchoolDegree);
    $("#education").append(formattedSchoolMajors);
    $("#education").append(formattedSchoolDates);

    $("#education").append(formattedOnlineTitle);
    $("#education").append(formattedOnlineSchool);
    $("#education").append(formattedOnlineDates);
    $("#education").append(formattedOnlineURL);
    
}

education();